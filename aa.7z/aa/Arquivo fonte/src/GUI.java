import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;

public class GUI {
  int i = 0;
  
  String sucesso = "Host disponivel\n\n";
  
  String falha = "Host invalido\n\n";
  
  String lento = "Host levemente lento\n\n";
  
  String lentidao = "Host lento";
  
  String original = "";
  
  public volatile boolean flag = true;
  
  JTextPane tp = new JTextPane();
  
  URL url;
  
  JScrollPane scroll = new JScrollPane();
  
  public Runnable t1;
  
  public Runnable t2;
  
  GUI() {
    this.t1 = new Runnable() {
        public void run() {
          pingCheck();
        }
      };
    this.t2 = new Runnable() {
        public void run() {
          try {
            httpCheck();
          } catch (IOException e) {
            e.printStackTrace();
          } 
        }
      };
    ImageIcon icon = new ImageIcon("img/transparentVV.png");
    ImageIcon logo = new ImageIcon("img/logo.png");
    Image image = logo.getImage();
    Image novaImg = image.getScaledInstance(200, 55, 4);
    logo = new ImageIcon(novaImg);
    final JFrame frame = new JFrame("Vivver Sistemas - Verificador de Status");
    JPanel panel0 = new JPanel();
    JPanel panel1 = new JPanel();
    JPanel panel2 = new JPanel();
    JPanel panel3 = new JPanel();
    JPanel panel4 = new JPanel();
    JPanel panel5 = new JPanel();
    JLabel label1 = new JLabel();
    JLabel label2 = new JLabel("Verificador de Status", 0);
    JLabel label3 = new JLabel("Clientes", 0);
    JLabel labelB = new JLabel();
    JLabel labelC = new JLabel();
    final JButton button1 = new JButton("Verificapor ping");
    final JButton button2 = new JButton("Limpar");
    final JButton button3 = new JButton("Verificapor HTTP");
    final JButton button4 = new JButton("Inserir");
    final JButton button5 = new JButton("Atualizar");
    JScrollPane scroll2 = new JScrollPane(this.tp);
    this.tp.setBackground((Color)null);
    this.tp.setBorder(new EmptyBorder(10, 10, 10, 10));
    listCheck();
    button1.setVisible(true);
    button1.setPreferredSize(new Dimension(375, 40));
    button1.setFocusable(false);
    button1.setFont(new Font("Arial", 1, 20));
    button1.setForeground(new Color(15658734));
    button1.setBackground(new Color(91550));
    button1.setCursor(new Cursor(12));
    button1.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            button1.setBackground(new Color(2463777));
          }
          
          public void mouseExited(MouseEvent evt) {
            button1.setBackground(new Color(91550));
          }
        });
    appendToPane(this.tp, "", Color.green);
    button1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (e.getSource() == button1) {
              tp.setText("");
              (new Thread(t1)).start();
            } 
          }
        });
    button2.setHorizontalAlignment(0);
    button2.setPreferredSize(new Dimension(0, 40));
    button2.setFocusable(false);
    button2.setFont(new Font("Arial", 1, 20));
    button2.setForeground(new Color(15658734));
    button2.setBackground(new Color(91550));
    button2.setCursor(new Cursor(12));
    button2.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            button2.setBackground(new Color(2463777));
          }
          
          public void mouseExited(MouseEvent evt) {
            button2.setBackground(new Color(91550));
          }
        });
    button2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (e.getSource() == button2)
              tp.setText(""); 
          }
        });
    button3.setVisible(true);
    button3.setPreferredSize(new Dimension(375, 40));
    button3.setFocusable(false);
    button3.setFont(new Font("Arial", 1, 20));
    button3.setForeground(new Color(15658734));
    button3.setBackground(new Color(91550));
    button3.setCursor(new Cursor(12));
    button3.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            button3.setBackground(new Color(2463777));
          }
          
          public void mouseExited(MouseEvent evt) {
            button3.setBackground(new Color(91550));
          }
        });
    button3.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (e.getSource() == button3) {
              tp.setText("");
              (new Thread(t2)).start();
            } 
          }
        });
    button4.setVisible(true);
    button4.setFocusable(false);
    button4.setFont(new Font("Arial", 1, 14));
    button4.setForeground(new Color(15658734));
    button4.setBackground(new Color(91550));
    button4.setPreferredSize(new Dimension(92, 30));
    button4.setCursor(new Cursor(12));
    button4.setBorder(new EmptyBorder(10, 0, 10, 0));
    button4.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            button4.setBackground(new Color(2463777));
          }
          
          public void mouseExited(MouseEvent evt) {
            button4.setBackground(new Color(91550));
          }
        });
    button4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (e.getSource() == button4);
            new insert();
          }
        });
    button5.setVisible(true);
    button5.setFocusable(false);
    button5.setFont(new Font("Arial", 1, 14));
    button5.setForeground(new Color(15658734));
    button5.setBackground(new Color(91550));
    button5.setPreferredSize(new Dimension(92, 30));
    button5.setCursor(new Cursor(12));
    button5.setBorder(new EmptyBorder(10, 0, 10, 0));
    button5.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            button5.setBackground(new Color(2463777));
          }
          
          public void mouseExited(MouseEvent evt) {
            button5.setBackground(new Color(91550));
          }
        });
    button5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (e.getSource() == button5)
              frame.dispose();
            	new GUI();
          }
        });
    this.scroll.setPreferredSize(new Dimension(20, 0));
    this.scroll.setBorder(BorderFactory.createEmptyBorder());
    this.scroll.getVerticalScrollBar().setBackground(new Color(13421772));
    this.scroll.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
          protected void configureScrollBarColors() {
            this.thumbColor = new Color(91550);
          }
        });
    label2.setFont(new Font("Arial", 1, 36));
    label3.setFont(new Font("Arial", 1, 20));
    label3.setForeground(new Color(3355443));
    labelB.setLayout(new BorderLayout());
    labelB.add(button1, "West");
    labelB.add(button3, "East");
    labelB.setPreferredSize(new Dimension(800, 40));
    labelC.setLayout(new BorderLayout());
    labelC.add(button4, "West");
    labelC.add(button5, "East");
    labelC.setPreferredSize(new Dimension(200, 40));
    labelC.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
    panel5.setBorder(new EmptyBorder(5, 5, 0, 5));
    panel5.setBackground(new Color(13421772));
    panel5.setLayout(new BorderLayout());
    panel5.add(this.scroll, "Center");
    panel5.add(labelC, "South");
    panel0.setBackground(new Color(91550));
    panel0.setPreferredSize(new Dimension(0, 30));
    panel1.setBackground(new Color(15658734));
    panel1.setPreferredSize(new Dimension(600, 300));
    panel1.setBorder(new EmptyBorder(10, 10, 10, 10));
    panel1.setLayout(new BorderLayout());
    panel1.add(labelB, "North");
    panel1.add(button2, "South");
    scroll2.setPreferredSize(new Dimension(20, 0));
    scroll2.setBorder(BorderFactory.createEmptyBorder());
    scroll2.getVerticalScrollBar().setBackground(new Color(15658734));
    scroll2.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
          protected void configureScrollBarColors() {
            this.thumbColor = new Color(91550);
          }
        });
    panel1.add(scroll2);
    panel2.setBackground(new Color(13421772));
    panel2.setPreferredSize(new Dimension(200, 0));
    panel2.setLayout(new BorderLayout());
    panel2.setBorder(new EmptyBorder(10, 0, 0, 0));
    panel3.setBackground(Color.white);
    panel3.setPreferredSize(new Dimension(0, 100));
    panel3.setLayout(new BorderLayout());
    label1.setIcon(logo);
    panel4.setBackground(new Color(91550));
    panel4.setPreferredSize(new Dimension(0, 20));
    frame.setLayout(new BorderLayout());
    panel3.add(label1, "West");
    panel3.add(panel0, "North");
    panel3.add(label2, "Center");
    frame.add(panel1, "Center");
    frame.add(panel2, "West");
    frame.add(panel3, "North");
    panel2.add(panel4, "South");
    panel2.add(label3, "North");
    panel2.add(panel5, "Center");
    frame.setDefaultCloseOperation(3);
    frame.setSize(1000, 600);
    frame.setMinimumSize(new Dimension(700, 400));
    frame.setIconImage(icon.getImage());
    frame.setLocationRelativeTo((Component)null);
    frame.setVisible(true);
  }
  
  private void appendToPane(JTextPane tp, String msg, Color c) {
    StyleContext sc = StyleContext.getDefaultStyleContext();
    StyledDocument doc = tp.getStyledDocument();
    AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);
    aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Courier New");
    aset = sc.addAttribute(aset, StyleConstants.Alignment, Integer.valueOf(3));
    aset = sc.addAttribute(aset, StyleConstants.FontSize, Integer.valueOf(14));
    int len = tp.getDocument().getLength();
    tp.setCaretPosition(len);
    tp.setCharacterAttributes(aset, false);
    tp.replaceSelection(msg);
    tp.setEditable(false);
    try {
      doc.insertString(doc.getLength(), msg, aset);
    } catch (BadLocationException e) {
      e.printStackTrace();
    } 
  }
  
  private void listCheck() {
    final File arquivo1 = new File("clientes.csv");
    try {
      if (!arquivo1.exists())
        System.out.println("Arquivo nencontrado"); 
      FileReader fr = new FileReader(arquivo1);
      BufferedReader br = new BufferedReader(fr);
      Vector<String> linhas = new Vector<>();
      String linha = "";
      while ((linha = br.readLine()) != null) {
        String[] partes = linha.split(";");
        linhas.add(partes[1]);
        this.i++;
      } 
      final JList<String> lista = new JList<>(linhas);
      MouseListener mouseListener = new MouseAdapter() {
          public void mouseClicked(MouseEvent e) {
            if (SwingUtilities.isLeftMouseButton(e) && e.getClickCount() == 2) {
              int index = lista.getSelectedIndex();
              String linha2 = "";
              try {
                FileReader frT = new FileReader(arquivo1);
                BufferedReader brT = new BufferedReader(frT);
                try {
                  while ((linha2 = brT.readLine()) != null) {
                    String[] parts = linha2.split(";");
                    int partInt = Integer.parseInt(parts[0]);
                    if (index + 1 == partInt) {
                      URL url = new URL(parts[2]);
                      HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                      connection.setRequestMethod("GET");
                      connection.connect();
                      int code = connection.getResponseCode();
                      String string = connection.getResponseMessage();
                      if (code == 200 || code == 301) {
                        if (url.toString().length() < 70) {
                          int numPontos = 70 - url.toString().length();
                          char c = '.';
                          char[] repeat = new char[numPontos];
                          Arrays.fill(repeat, c);
                          original = new String(repeat);
                          appendToPane(tp, url + "  " + original + " " + string + "\n\n", new Color(2463777));
                        } 
                      } else if (url.toString().length() < 70) {
                        int numPontos = 70 - url.toString().length();
                        char c = '.';
                        char[] repeat = new char[numPontos];
                        Arrays.fill(repeat, c);
                        original = new String(repeat);
                        appendToPane(tp, url + "  " + original + " " + string + "\n\n", Color.red);
                      } 
                      try {
                        InetAddress endereco = InetAddress.getByName(url.getHost());
                        String temp = endereco.toString();
                        String ip = temp.substring(temp.indexOf("/") + 1, temp.length());
                        if (url.toString().length() < 70) {
                          int numPontos = 70 - url.toString().length();
                          char c = '.';
                          char[] repeat = new char[numPontos];
                          Arrays.fill(repeat, c);
                          original = new String(repeat);
                          appendToPane(tp, url + "  " + original + " " + sucesso, new Color(2463777));
                        } else {
                          System.out.print(url);
                        } 
                        solicitacaoPing(ip);
                      } catch (UnknownHostException e2) {
                        if (url.toString().length() < 70) {
                          int numPontos = 70 - url.toString().length();
                          char c = '.';
                          char[] repeat = new char[numPontos];
                          Arrays.fill(repeat, c);
                          original = new String(repeat);
                          appendToPane(tp, url + "  " + original + " " + falha, Color.red);
                          continue;
                        } 
                        System.out.print(url);
                      } 
                    } 
                  } 
                } catch (IOException e1) {
                  e1.printStackTrace();
                } 
              } catch (FileNotFoundException e1) {
                e1.printStackTrace();
              } 
            } 
            if (SwingUtilities.isRightMouseButton(e) && e.getClickCount() == 1) {
              String string = lista.getSelectedValue();
              System.out.println(string);
            } 
          }
        };
      lista.addMouseListener(mouseListener);
      lista.setForeground(Color.black);
      lista.setFont(new Font("Calibri", 0, 14));
      lista.setBackground(new Color(13421772));
      lista.setBorder(BorderFactory.createEmptyBorder());
      lista.setSelectionBackground(new Color(13421772));
      this.scroll.setViewportView(lista);
      br.close();
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  
  private void pingCheck() {
    File arquivo = new File("clientes.csv");
    try {
      if (!arquivo.exists())
        appendToPane(this.tp, "Arquivo nao encontrado", Color.black); 
      FileReader fr = new FileReader(arquivo);
      BufferedReader br = new BufferedReader(fr);
      while (br.ready()) {
        String linha = br.readLine();
        String[] partes = linha.split(";");
        this.url = new URL(partes[2]);
        try {
          InetAddress endereco = InetAddress.getByName(this.url.getHost());
          String temp = endereco.toString();
          String ip = temp.substring(temp.indexOf("/") + 1, temp.length());
          if (this.url.toString().length() < 70) {
            int numPontos = 70 - this.url.toString().length();
            char c = '.';
            char[] repeat = new char[numPontos];
            Arrays.fill(repeat, c);
            this.original = new String(repeat);
            appendToPane(this.tp, this.url + "  " + this.original + " " + this.sucesso, new Color(2463777));
          } else {
            System.out.print(this.url);
          } 
          solicitacaoPing(ip);
        } catch (UnknownHostException e2) {
          if (this.url.toString().length() < 70) {
            int numPontos = 70 - this.url.toString().length();
            char c = '.';
            char[] repeat = new char[numPontos];
            Arrays.fill(repeat, c);
            this.original = new String(repeat);
            appendToPane(this.tp, this.url + "  " + this.original + " " + this.falha, Color.red);
            continue;
          } 
          System.out.print(this.url);
        } 
      } 
      br.close();
      fr.close();
    } catch (IOException ex) {
      ex.printStackTrace();
    } 
  }
  
  private void httpCheck() throws IOException {
    File arquivo = new File("clientes.csv");
    if (!arquivo.exists())
      appendToPane(this.tp, "Arquivo nao encontrado", Color.black); 
    FileReader fr = new FileReader(arquivo);
    BufferedReader br = new BufferedReader(fr);
    Vector<String> linhas = new Vector<>();
    String linha = "";
    URL url = null;
    while ((linha = br.readLine()) != null) {
      String[] partes = linha.split(";");
      linhas.add(partes[2]);
      url = new URL(partes[2]);
      HttpURLConnection connection = (HttpURLConnection)url.openConnection();
      connection.setRequestMethod("GET");
      connection.connect();
      int code = connection.getResponseCode();
      String string = connection.getResponseMessage();
      if (code == 200 || code == 301) {
        if (url.toString().length() < 70) {
          int numPontos = 70 - url.toString().length();
          char c = '.';
          char[] repeat = new char[numPontos];
          Arrays.fill(repeat, c);
          this.original = new String(repeat);
          appendToPane(this.tp, url + "  " + this.original + " " + string + "\n\n", new Color(2463777));
        } 
        continue;
      } 
      if (url.toString().length() < 70) {
        int numPontos = 70 - url.toString().length();
        char c = '.';
        char[] repeat = new char[numPontos];
        Arrays.fill(repeat, c);
        this.original = new String(repeat);
        appendToPane(this.tp, url + "  " + this.original + " " + string + "\n\n", Color.red);
      } 
    } 
    br.close();
    fr.close();
  }
  
  public void solicitacaoPing(String enderecoIP) throws UnknownHostException, IOException {
    InetAddress vivver = InetAddress.getByName(enderecoIP);
    String ip = vivver.toString();
    ip = ip.replace("/", "");
    if (!vivver.isReachable(20))
      if (!vivver.isReachable(30))
        if (!vivver.isReachable(40))
          if (!vivver.isReachable(50))
            if (vivver.isReachable(100)) {
              appendToPane(this.tp, this.url + "  " + this.original + " " + this.lento, new Color(14329120));
            } else {
              appendToPane(this.tp, this.url + "  " + this.original + " " + this.lentidao, new Color(16747520));
            }     
  }
}
