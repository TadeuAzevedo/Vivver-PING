import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class insert {
  int i = 0;
  
  insert() {
    getI();
    ImageIcon icon = new ImageIcon("img/transparentVV.png");
    ImageIcon logo = new ImageIcon("img/logo.png");
    Image image = logo.getImage();
    Image novaImg = image.getScaledInstance(200, 55, 4);
    logo = new ImageIcon(novaImg);
    final JFrame frame = new JFrame("Vivver Sistemas - Inserir cliente");
    JPanel panel1 = new JPanel();
    JPanel panel2 = new JPanel();
    JPanel panel3 = new JPanel();
    JPanel panel4 = new JPanel();
    JPanel panel5 = new JPanel();
    JLabel lb1 = new JLabel("Inserir cliente", 0);
    JLabel lb2 = new JLabel("Cliente:");
    JLabel lb3 = new JLabel("URL:");
    final JTextField tf1 = new JTextField();
    final JTextField tf2 = new JTextField();
    final JButton button = new JButton("Enviar");
    button.setVisible(true);
    button.setFocusable(false);
    button.setFont(new Font("Arial", 1, 18));
    button.setForeground(new Color(15658734));
    button.setBackground(new Color(91550));
    button.setCursor(new Cursor(12));
    button.setBorder(new EmptyBorder(10, 0, 10, 0));
    button.setPreferredSize(new Dimension(400, 50));
    button.addMouseListener(new MouseAdapter() {
          public void mouseEntered(MouseEvent evt) {
            button.setBackground(new Color(2463777));
          }
          
          public void mouseExited(MouseEvent evt) {
            button.setBackground(new Color(91550));
          }
        });
    button.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (e.getSource() == button) {
              try {
                BufferedWriter bw = new BufferedWriter(new FileWriter("clientes.csv", true));
                bw.write(String.valueOf(insert.this.i + 1) + ";" + tf1.getText() + ";" + tf2.getText() + System.lineSeparator());
                bw.close();
              } catch (Exception ex) {
                ex.printStackTrace();
              } 
              frame.dispose();
            } 
          }
        });
    lb1.setFont(new Font("Arial", 1, 34));
    lb2.setFont(new Font("Arial", 1, 18));
    lb2.setPreferredSize(new Dimension(400, 50));
    lb3.setFont(new Font("Arial", 1, 18));
    lb3.setPreferredSize(new Dimension(400, 50));
    tf1.setPreferredSize(new Dimension(400, 30));
    tf1.setFont(new Font("Arial", 0, 15));
    tf2.setPreferredSize(new Dimension(400, 30));
    tf2.setFont(new Font("Arial", 0, 15));
    panel1.setBackground(new Color(15658734));
    panel1.setBorder(new EmptyBorder(10, 10, 10, 10));
    panel1.setLayout(new BorderLayout());
    panel1.add(panel5, "Center");
    panel5.add(lb2);
    panel5.add(tf1);
    panel5.add(lb3);
    panel5.add(tf2);
    panel1.add(button, "South");
    panel2.setLayout(new BorderLayout());
    panel2.setBackground(Color.white);
    panel2.setPreferredSize(new Dimension(0, 100));
    panel2.add(lb1);
    panel3.setBackground(new Color(91550));
    panel3.setPreferredSize(new Dimension(0, 30));
    panel2.add(panel3, "North");
    panel4.setBackground(new Color(91550));
    panel4.setPreferredSize(new Dimension(0, 20));
    frame.setLayout(new BorderLayout());
    frame.add(panel1, "Center");
    frame.add(panel2, "North");
    frame.add(panel4, "South");
    frame.setDefaultCloseOperation(2);
    frame.setSize(500, 600);
    frame.setIconImage(icon.getImage());
    frame.setLocationRelativeTo((Component)null);
    frame.setVisible(true);
  }
  
  private void getI() {
    File arquivo1 = new File("clientes.csv");
    try {
      if (!arquivo1.exists())
        System.out.println("Arquivo nencontrado"); 
      FileReader fr = new FileReader(arquivo1);
      BufferedReader br = new BufferedReader(fr);
      while (br.readLine() != null)
        this.i++; 
    } catch (Exception ex) {
      ex.printStackTrace();
    } 
  }
}