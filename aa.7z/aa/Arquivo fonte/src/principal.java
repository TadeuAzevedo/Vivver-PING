import java.io.*;

public class principal {

	public static void main(String[] args) throws IOException{
		new GUIteste();
	}

}